package GUI;

public class Main {
	public static View frame;
	public static Controller controller;
	public static Movielist movie;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		frame = new View();
		frame.setVisible(true);
		controller = new Controller();
		movie = new Movielist();
		movie.addMovie();	
	}

}
